from flask import Flask, request, abort
import time
from  datetime import datetime
import numpy as np
import random
import numpy as np
r = random.sample(range(10),4)
app = Flask(__name__)
db = [
    {
        'text': 'uuuuu',
        'time': time.time(),
        'name': 'Nick'
    },
    {
        'text': 'iiiiiii',
        'time': time.time()+1,
        'name': 'Jane'
    }
]


@app.route("/")
def hello():
    return "hello   world 222 !!"


@app.route("/status")
def status():
    now= datetime.now()
    return {
        'status': True,
        'name':'Silbox',
        'time1':time.time(),
        'time2': time.asctime(),
        'time3':now,
        'time4': str(now),
        'time6': now.strftime("/%Y/%m/%d %H:%M:%S")
    }


@app.route("/send", methods=['POST'])
def send_message():
    if not isinstance(request.json,dict):
        return abort(400)
    name = request.json.get('name')
    text = request.json.get('text')
    if not isinstance(name, str):
        return abort(400)
    if not isinstance(text, str):
        return abort(400)
    if name == '':
        return abort(400)
    if text == '':
        return abort(400)
    x = int(text)
    result = []
    while x > 0:
        result.append(x % 10)
        x //= 10
        result.reverse()

    c = []
    for i in r:
        if i in c:
            continue
        for j in result:
            if i == j:
                c.append(i)
                break
    m = len(c)
    pos = 0
    for i in range(4):
        if r[i] == result[i]:
            pos = pos + 1
    message = {
        'text': text+" "+str(m)+":"+str(pos),
        'time': time.time(),
        'name': name
    }
    db.append(message)
    return {
        'ok': True
    }


@app.route("/messages")
def get_message():
    try:
        after = float(request.args['after'])
    except:
        return abort(400)
    messages = []
    for message in db:
        if message['time'] > after:
            messages.append(message)
    return {'messages': messages[:100 ]}




app.run()
